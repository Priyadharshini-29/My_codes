#include <iostream>

using namespace std;

int main()
{
    int n1,n2;
    cin>>n1>>n2;
    int arr[n1][n2];
    int r,c;
    for(r=0;r<n1;r++)
    {
        for(c=0;c<n2;c++)
        {
            cin>>arr[r][c];
        }
    }
    int start,e;
    for(r=0;r<n1;r++)
    {
        start=0,e=r;
        while(start<n1 && e<n1)
        {
            cout<<arr[start][e]<<" ";
             start++;
        e++;

        }

    }

    for(r=1;r<n1;r++)
    {
        start=r,e=0;
        while(start<n1 && e<n1)
        {
            cout<<arr[start][e]<<" ";
            start++;
            e++;
        }

    }
    return 0;
}
